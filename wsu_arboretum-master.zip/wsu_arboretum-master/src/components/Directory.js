import React from "react";
import { Box, Heading, Image } from "@chakra-ui/react";
import logo from "../img/arboretum_logo.jpg"

const Directory = (props) => {
    return (
        <Box h="100%">
            <Heading>
                Directory under construction...
            </Heading>
        </Box>
    );
}

export default Directory;